#!/bin/bash
echo "run 'mysql -uroot -p' for terminal access"
docker exec -it mariadb bash