<?php
$cfg['blowfish_secret'] = 'nrG@r5wS4K8LP!V~1}WCBv?]2D^=LzQB';
